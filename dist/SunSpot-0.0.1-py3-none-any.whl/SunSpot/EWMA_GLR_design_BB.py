# -*- coding: utf-8 -*-
"""
Created on Thu May  7 17:30:50 2020

@author: sopmathieu
"""

import numpy as np 
from sklearn.utils import resample
from scipy.stats import moment
import BB_methods as BB

def search_GLR(data, lambd, ARL0_treshold=200, rho=2, block_length=27,
                 L_plus=20, L_minus=0, nmc=4000, n=4000, verbose=True):
    """ 
    Compute the control limit of the EWMA_GLR chart for a pre-specified 
    value of ARL0 and a particular shift size 
    
    Arguments:
    data:          IC dataset (not the blocks)
    lambd:         array containing different values for parameter lambda
    ARL0_treshold: pre-specified value of ARL0 that we want to reach
    rho:           accuracy=> |ARL0-ARL0_treshold|>rho
    block_length:  length of the block
    L_plus:        upper value of the control limit
    L_minus:       lower value of the control limit
    nmc:           number of Monte-Carlo runs
    n:             length of the resampled series at each run
    verbose:       boolean (True=print intermediate results)
    
    Return:
    L:             control limit
    """
    
    (n_obs, n_series) = data.shape
    L = (L_plus + L_minus)/2
    dzeta = moment(data.flatten(), moment=4, nan_policy='omit')
    blocks = BB.MBB(data, block_length)
    n_blocks = int(np.ceil(n/blocks.shape[1]))
    nset = len(lambd)

    ARL = 0
    while (np.abs(ARL - ARL0_treshold) > rho):
        RL = np.zeros((nmc,1)); RL[:] = np.nan
        for b in range(nmc):
            
            boot = resample(blocks, replace=True, n_samples=n_blocks).flatten()[:n]
            
            ###monitoring
            w = 1 - lambd
            alpha = np.zeros((n, nset)); beta = np.zeros((n, nset))
            EWstat = np.zeros((n, nset)); VarWstat = np.ones((n, nset)); CovWstat = np.zeros((n, nset))
            #Esp = np.zeros((n)); Var = np.zeros((n))
            W_plus = np.zeros((n,nset)); W_plus[1:,:] = np.nan
            W_stn = np.zeros((n,nset)); W_stn[1:,:] = np.nan
            g = np.zeros((n,nset))
                       
                
            for i in range(1, n):
                for j in range(nset): 
    
                    alpha[i,j] = alpha[i-1,j]*w[j] + 1
                    beta[i,j] = beta[i-1,j] * w[j]**2 + 1
                    g[i,j] = (alpha[i-1,j]*g[i-1,j] + boot[i])/alpha[i,j] #estimation of shift size
                    W_plus[i,j] = W_plus[i-1,j]*w[j] + (2*boot[i] - g[i,j])*g[i,j] #opposite sign as the shift
                    ### mean 
                    EWstat[i,j] = (2/alpha[i,j] - beta[i,j]/alpha[i,j]**2) + w[j]*EWstat[i-1,j]
                    #Esp[i] = np.nanmean(W_plus[(i-40):i])
                    ### variance
                    if i > 1:
                        v1 = 4 * (dzeta + beta[i-1,j] * w[j]**2) / alpha[i,j]**2
                        v2 = dzeta * beta[i,j]**2 / alpha[i,j]**4
                        v3 = 4 * (dzeta + 3*beta[i-1,j] * w[j]**2) / alpha[i,j]**3
                        v4 = (2/alpha[i,j] - beta[i,j]/alpha[i,j]**2)**2
                        c1 = alpha[i-1,j]**2 * w[j]**2 * w[j]**2
                        c2 = (1/alpha[i-1,j]) * w[j]**2 * (dzeta + 3*beta[i-2,j] * w[j]**2 - beta[i-1,j])
                        c3 = (1/alpha[i-1,j]**2) * w[j]**2 * beta[i-1,j]**2
                        CovWstat[i,j] = (c1*CovWstat[i-1,j] + c2 - c3) / alpha[i,j]**2
                        VarWstat[i,j] = VarWstat[i-1,j] * w[j]**2 + v1 + v2 - v3 - v4 -2*w[j]*CovWstat[i-1,j]
                        #Var[i] = np.nanvar(W_plus[(i-40):i])
                        W_stn[i,j] = (W_plus[i,j] - EWstat[i,j]) / np.sqrt(VarWstat[i,j])
                    
                    else: 
                        W_stn[i,j] = (W_plus[i,j] - EWstat[i,j])
                
                W_max = max(W_stn[i,:])
                if W_max > L or W_max < -L:
                    RL[b] = i
                    break 
                    
        ARL = np.nanmean(RL)
        if ARL < ARL0_treshold:
            L_minus = (L_minus + L_plus)/2
        elif ARL > ARL0_treshold:
            L_plus = (L_minus + L_plus)/2
        L = (L_plus + L_minus)/2
            
        if verbose:
            print(ARL)
            print(L)
            
    return L



def ARL1_GLR(data, lambd, L, form='jump', delta=1.5, nmc=4000, n=4000, 
             eta=0.04, block_length=27):
    """ 
    Compute the ARL1 of the EWMA-GLR chart for a simulated shift of size delta
    and form between 'jump', 'oscill' and 'trend'.
    
    Arguments:
    data:          IC dataset (not the blocks)
    lambd:         array containing several values for parameter lambda
    L:             value of the control limit
    form:          form of the simulated shift ('jump', 'oscill', 'trend')
    delta:         shift size 
    nmc:           number of Monte-Carlo runs
    n:             length of the resampled/simulated series at each run
    eta:           parameter of the oscillating shift 
    block_length:  length of the block
    
    Return:
    ARL:           ARL_1 value 
    """
    
    (n_obs, n_series) = data.shape
    shift = delta
    dzeta = moment(data.flatten(), moment=4, nan_policy='omit')
    blocks = BB.MBB(data, block_length)
    n_blocks = int(np.ceil(n/blocks.shape[1]))
    nset = len(lambd)

    RL1_p = np.zeros((nmc,1));  RL1_p[:] = np.nan
    for b in range(nmc):
        
        boot = resample(blocks, replace=True, n_samples=n_blocks).flatten()[:n]
        if form == 'oscill':
            boot = np.sin(eta*np.pi*np.arange(n))*shift + boot
            pass
        elif form == 'trend':
            #boot = shift/(4*n)*(np.arange(n)**2) + boot
            boot = shift/(150)*(np.arange(n)**1.5) + boot
            pass
        else: 
            boot = boot + shift
            pass

   
        ###monitoring
        w = 1 - lambd
        alpha = np.zeros((n, nset)); beta = np.zeros((n, nset))
        EWstat = np.zeros((n, nset)); VarWstat = np.ones((n, nset)); CovWstat = np.zeros((n, nset))
        #Esp = np.zeros((n)); Var = np.zeros((n))
        W_plus = np.zeros((n,nset)); W_plus[1:,:] = np.nan
        W_stn = np.zeros((n,nset)); W_stn[1:,:] = np.nan
        g = np.zeros((n,nset))
                   
            
        for i in range(1, n):
            for j in range(nset): 

                alpha[i,j] = alpha[i-1,j]*w[j] + 1
                beta[i,j] = beta[i-1,j] * w[j]**2 + 1
                g[i,j] = (alpha[i-1,j]*g[i-1,j] + boot[i])/alpha[i,j] #estimation of shift size
                W_plus[i,j] = W_plus[i-1,j]*w[j] + (2*boot[i] - g[i,j])*g[i,j] #opposite sign as the shift
                ### mean 
                EWstat[i,j] = (2/alpha[i,j] - beta[i,j]/alpha[i,j]**2) + w[j]*EWstat[i-1,j]
                #Esp[i] = np.nanmean(W_plus[(i-40):i])
                ### variance
                if i > 1:
                    v1 = 4 * (dzeta + beta[i-1,j] * w[j]**2) / alpha[i,j]**2
                    v2 = dzeta * beta[i,j]**2 / alpha[i,j]**4
                    v3 = 4 * (dzeta + 3*beta[i-1,j] * w[j]**2) / alpha[i,j]**3
                    v4 = (2/alpha[i,j] - beta[i,j]/alpha[i,j]**2)**2
                    c1 = alpha[i-1,j]**2 * w[j]**2 * w[j]**2
                    c2 = (1/alpha[i-1,j]) * w[j]**2 * (dzeta + 3*beta[i-2,j] * w[j]**2 - beta[i-1,j])
                    c3 = (1/alpha[i-1,j]**2) * w[j]**2 * beta[i-1,j]**2
                    CovWstat[i,j] = (c1*CovWstat[i-1,j] + c2 - c3) / alpha[i,j]**2
                    VarWstat[i,j] = VarWstat[i-1,j] * w[j]**2 + v1 + v2 - v3 - v4 -2*w[j]*CovWstat[i-1,j]
                    #Var[i] = np.nanvar(W_plus[(i-40):i])
                    W_stn[i,j] = (W_plus[i,j] - EWstat[i,j]) / np.sqrt(VarWstat[i,j])
                
                else: 
                    W_stn[i,j] = (W_plus[i,j] - EWstat[i,j])
                

            W_max = max(W_stn[i,:])
            if W_max > L or W_max < -L:
                RL1_p[b] = i
                break 
        
        if np.isnan(RL1_p[b]): 
            RL1_p[b] = n
    
        
    ARL1 = np.mean(RL1_p) 
    return ARL1


##########################################################################"
""" Tests """

if __name__ == "__main__":  
    
    data = np.random.normal(0, 1, size=(10000,1))

    #check paper
    lambd = np.array([0.005, 0.05, 0.1, 0.2])
    search_GLR(data, lambd, L_plus=5, verbose=True, n=1000, block_length=1) 
    np.log(ARL1_GLR(data, lambd, L=3.5, delta=0.5, n=1000, block_length=1)) #3.08
    np.log(ARL1_GLR(data, lambd, L=3.5, form='trend', n=1000, delta=0.5, block_length=1)) #3.95
    np.log(ARL1_GLR(data, lambd, L=3.5, form='oscill', n=1000, delta=0.5, eta=0.25, block_length=1)) #4.9
    ### again
    np.log(ARL1_GLR(data, lambd, L=3.5, delta=2, n=1000, block_length=1)) #0.78
    np.log(ARL1_GLR(data, lambd, L=3.5, form='trend', n=1000, delta=5, block_length=1)) #3.2
    np.log(ARL1_GLR(data, lambd, L=3.5, form='oscill', n=1000, delta=2, eta=0.25, block_length=1)) #2
    
    lambd=np.array([0.05])
    search_GLR(data, lambd, L_plus=10, verbose=True, n=1000, block_length=1) 
    np.log(ARL1_GLR(data, lambd, L=7.73, delta=2, n=1000, block_length=1)) ##1.44
    np.log(ARL1_GLR(data, lambd, L=7.73, form='trend', n=1000, delta=5, block_length=1)) #3.5
    np.log(ARL1_GLR(data, lambd, L=7.73, form='oscill', n=1000, delta=2, eta=0.25, block_length=1)) #5
     
    ### compare performances with other charts
    lambd=np.array([0.005, 0.05, 0.1, 0.2])
    search_GLR(data, lambd, L_plus=5, verbose=True, block_length=1) #3.36
    ARL1_GLR(data, lambd, L=3.36, delta=0.2, block_length=1) #82.78
    ARL1_GLR(data, lambd, L=3.36, delta=0.5, block_length=1) #21.61
    ARL1_GLR(data, lambd, L=3.36, delta=1, block_length=1) #6.78
    ARL1_GLR(data, lambd, L=3.36, delta=2, block_length=1) #2.115
    

    
