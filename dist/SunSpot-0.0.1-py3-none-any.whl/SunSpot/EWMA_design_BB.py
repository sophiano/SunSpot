# -*- coding: utf-8 -*-
"""
Created on Thu May  7 17:30:50 2020

@author: sopmathieu
"""

import numpy as np 
from sklearn.utils import resample
import pickle  
import sys
sys.path.insert(1, '../..')
       
from Block_Bootstrap import BB_methods as BB

def ARL0_EWMA_MV(data, rho, lambd=0.2, nmc=4000, n=4000, missing_values='omit', 
                  gap=7, block_length=None):
    """ 
    Compute the ARL0 of the 2-sided EWMA chart for a control limit value
    and a particular shift size in presence of missing values.
    
    Arguments:
    data:           IC dataset (not the blocks)
    rho:            control limit
    lambd:          weighting parameter
    nmc:            number of Monte-Carlo runs
    n:              length of the resampled series 
    missing_values: how to treat the missing values. 
                    'omit' removes the blocks containing missing values 
                    'filled' fills-up the MV by the mean of each series 
                    'reset' reset the chart after a gap of # days
    gap:            length of the gap (period where the chart statistic is propagated)
    block_length:   length of the blocks
    
    Return:
    ARL:            ARL_0 value   
    """
    
    (n_obs, n_series) = data.shape    
    if missing_values == 'filled':
        for i in range(n_series):
            data[np.isnan(data[:,i]),i] = np.nanmean(data[:,i])#fill obs by the mean of the series
            
    ##Block bootstrap
    n_blocks = int(np.ceil(n/block_length))
    if missing_values == 'filled' or missing_values == 'omit':
         blocks = BB.MBB(data, block_length)    
    else:
         blocks = BB.MBB(data, block_length, NaN=True)
      
    #chart parameters
    L = rho*np.sqrt(lambd/(2 - lambd))

    RL = np.zeros((nmc,1)); RL[:] = np.nan
    for j in range(nmc):
        
        boot = resample(blocks, replace=True, n_samples=n_blocks).flatten()[:n]
        #boot=np.random.normal(0,1,size=n)
    

        Ewma = np.zeros((n, 1)) 
        cp = 0; nan_p = 0
        for i in range(1, n):
            if not np.isnan(boot[i]):
                Ewma[i] = (1-lambd)*Ewma[i-1] + lambd*boot[i] #Table 5.1 Qiu 
                cp = 0
            elif (np.isnan(boot[i]) and cp < gap):
                Ewma[i] = Ewma[i-1]
                cp += 1; nan_p += 1
            else: 
                Ewma[i] = 0 
                nan_p += 1
                
            if (Ewma[i] > L or Ewma[i] < -L):
                RL[j] = i #- nan_p
                break 
            
        if np.isnan(RL[j]):
            RL[j] = n #n-nan_p
                
    ARL = np.mean(RL)

    return ARL


def search_EWMA_MV(data, lambd=0.2, ARL0_threshold=200, acc=2, rho_plus=10, 
                    rho_minus=0, nmc=4000, n=4000, verbose=True,
                    missing_values='omit', gap=7, block_length=None):
    """ 
    Compute the control limit of the 2-side EWMA chart for a pre-specified value 
    of ARL0 and a particular shift size in presence of missing values.
    
    Arguments:
    data:            ICdataset 
    lambd:           weighting parameter
    ARL0_treshold:   pre-specified value of ARL0 
    acc:             accuracy: |ARL0-ARL0_treshold|>acc
    rho_plus:        upper value of the control limit
    rho_plus:        lower value of the control limit
    nmc:             number of Monte-Carlo runs
    n:               length of the resampled series 
    verbose:         boolean (when True: print intermediate results)
    missing_values:  how to treat the missing values. 
                     'omit': removes the blocks containing missing values 
                     'filled': fills-up the MV by the mean of each series 
                     'reset': resets the chart after a gap of # days
    gap:             length of the gap (period where the chart statistic is propagated)
    block_length:    length of the blocks 
    
    Return:
    rho:             control limit of the chart
    """
    
    (n_obs, n_series) = data.shape    
    if missing_values == 'filled':
        for i in range(n_series):
            data[np.isnan(data[:,i]),i] = np.nanmean(data[:,i]) #fill obs by the mean of the series
            
    ##Block bootstrap
    n_blocks = int(np.ceil(n/block_length))
    if missing_values == 'filled' or missing_values == 'omit':
         blocks = BB.MBB(data, block_length)
    else:
        blocks = BB.MBB(data, block_length, NaN=True)
         
    #chart parameters
    rho = (rho_plus + rho_minus)/2
    L = rho*np.sqrt(lambd/(2 - lambd))

    ARL = 0
    while (np.abs(ARL - ARL0_threshold) > acc):
        RL = np.zeros((nmc, 1)); RL[:] = np.nan
        for j in range(nmc):
            
            #boot = np.random.normal(0, 1, size=n)
            boot = resample(blocks,replace=True, n_samples=n_blocks).flatten()[:n]
            
            ### Monitoring ###
            Ewma = np.zeros((n, 1)) 
            cp = 0; nan_p = 0
            for i in range(1, n):
                if not np.isnan(boot[i]):
                    Ewma[i] = (1-lambd)*Ewma[i-1] + lambd*boot[i] 
                    cp = 0
                elif (np.isnan(boot[i]) and cp < gap):
                    Ewma[i] = Ewma[i-1]
                    cp += 1; nan_p += 1
                else: 
                    Ewma[i] = 0 
                    nan_p += 1
                    
                if (Ewma[i] > L or Ewma[i] < -L):
                    RL[j] = i # - nan_p
                    break 
                
            if np.isnan(RL[j]):
                RL[j] = n #n-nan_p
      

        ARL = np.mean(RL)
        if ARL < ARL0_threshold:
            rho_minus = (rho_minus + rho_plus)/2
        elif ARL > ARL0_threshold:
            rho_plus = (rho_minus + rho_plus)/2
        rho = (rho_plus + rho_minus)/2
        L = rho*np.sqrt(lambd/(2 - lambd))
            
        if verbose:
            print(ARL)
            print(rho)
            
    return rho

def ARL1_EWMA_MV(data, rho, lambd=0.2, form='jump',delta=1.5, 
                  nmc=4000, n=4000, eta=0.04, missing_values='omit', 
                  gap=7, block_length=None):
    """ 
    Compute the ARL1 of the 2-side EWMA chart for a simulated shift of size delta
    and form between 'jump', 'oscill' and 'trend'.
    
    Arguments:
    data:            IC dataset
    rho:             control limit
    lambd:           weighting parameter
    form:            form of the shift ('jump', 'oscill', 'trend')
    delta:           shift size 
    nmc:             number of Monte-Carlo runs
    n:               length of the resampled series
    eta:             parameter of the oscillating shift
    missing_values:  how to treat the missing values. 
                     'omit': removes the blocks containing missing values 
                     'filled': fills-up the MV by the mean of each series 
                     'reset': resets the chart after a gap of # days
    gap:              length of the gap (period where the chart statistic is propagated)
    block_length:     length of the blocks
    
    Return:
    ARL1:            ARL1 value of the chart
    """
    
    (n_obs, n_series) = data.shape    
    if missing_values == 'filled':
        for i in range(n_series):
            data[np.isnan(data[:,i]),i] = np.nanmean(data[:,i]) #fill obs by the mean of the series
        
    ##Block bootstrap
    n_blocks = int(np.ceil(n/block_length))
    if missing_values == 'filled' or missing_values == 'omit':
         blocks = BB.MBB(data, block_length)
    else:
        blocks = BB.MBB(data, block_length, NaN=True)
         
    #parameters
    L = rho*np.sqrt(lambd/(2 - lambd))
    shift = delta

    RL1 = np.zeros((nmc,1)); RL1[:] = np.nan
    for b in range(nmc):
        
        boot = resample(blocks, replace=True, n_samples=n_blocks).flatten()[:n]
        #boot = np.random.normal(0, 1, size=n)
        
        if form == 'oscill':
            boot = np.sin(eta*np.pi*np.arange(n))*shift + boot
            pass
        elif form == 'trend':
            #boot = shift/(4*n)*(np.arange(n)**2) + boot
            boot = shift/(150)*(np.arange(n)**1.5) + boot
            pass
        else: 
            boot = boot + shift
            pass

        Ewma = np.zeros((n,1)) 
        cp = 0; nan_p = 0
        for i in range(1, n):
            if not np.isnan(boot[i]):
                Ewma[i] = (1-lambd)*Ewma[i-1] + lambd*boot[i] 
                cp = 0
            elif (np.isnan(boot[i]) and cp < gap):
                Ewma[i] = Ewma[i-1]
                cp += 1; nan_p += 1
            else: 
                Ewma[i] = 0 
                nan_p += 1
                
            if (Ewma[i] > L or Ewma[i] < -L):
                RL1[b] = i #- nan_p
                break 
    
            
        if np.isnan(RL1[b]): 
            RL1[b] = n
#        if np.isnan(ARL1_minus[b]):
#            ARL1_minus[b] = n
            

    ARL1 = np.mean(RL1)
    return ARL1


def ARL_values_EWMA_MV(data, rho, lambd=0.2, form='jump',delta=1.5,
                  nmc=4000, n=8000, eta=0.04,
                  missing_values='omit', gap=7, block_length=None):
    """ 
    Compute the ARL1 and the ARL0 of the 2-sided EWMA chart for a simulated shift 
    of size delta and form between 'jump', 'oscill' and 'trend'.
    
    Arguments:
    data:             IC dataset
    rho:              control limit of the chart
    lambd:            weigthing parameter 
    form:             form of the shift ('jump', 'oscill', 'trend')
    delta:            shift size
    nmc:              number of Monte-Carlo runs
    n:                length of the resampled series 
    eta:              parameter of the oscillating shifts
    missing_values:   how to treat the missing values. 
                     'omit': removes the blocks containing missing values 
                     'filled': fills-up the MV by the mean of each series 
                     'reset': resets the chart after a gap of # days
    gap:              length of the gap (period where the chart statistic is propagated)
    block_length:     length of the blocks
    
    Return:
    ARL1, ARL0:     ARL1 and ARL0 values
    """
    
    (n_obs, n_series) = data.shape    
    if missing_values == 'filled':
        for i in range(n_series):
            data[np.isnan(data[:,i]),i] = np.nanmean(data[:,i]) #fill obs by the mean of the series
        
    ##Block bootstrap
    n_blocks = int(np.ceil(n/block_length))
    if missing_values == 'filled' or missing_values == 'omit':
         blocks = BB.MBB(data, block_length)
    else:
        blocks = BB.MBB(data, block_length, NaN=True)
    
    #chart parameters
    shift = delta
    L = rho*np.sqrt(lambd/(2 - lambd))
    n_shift = int(n/2)

    RL0 = np.zeros((nmc,1))
    RL1 = np.zeros((nmc,1)); RL1[:] = np.nan
    for b in range(nmc):
        
        boot = resample(blocks, replace=True, n_samples=n_blocks).flatten()[:n]
        #boot = np.random.normal(0, 1, size=n)
    
        if form == 'oscill':
            boot[n_shift:] = np.sin(eta*np.pi*np.arange(n_shift))*shift + boot[n_shift:]
            pass
        elif form == 'trend':
            #boot[n_shift:] = shift/(4*n_shift)*(np.arange(n_shift)**2) + boot[n_shift:]
            boot[n_shift:] = shift/(150)*(np.arange(n_shift)**1.5) + boot[n_shift:]
            pass
        else: 
            boot[n_shift:] = boot[n_shift:] + shift
            pass
        
        cnt_plus = 0; cp = 0 
        Ewma = np.zeros((n,1)); nan_p = np.zeros((n,1))
        for i in range(1, n):
            if not np.isnan(boot[i]):
                Ewma[i] = (1-lambd)*Ewma[i-1] + lambd*boot[i]
                Ewma[n_shift] = 0
                cp=0
            elif (np.isnan(boot[i]) and cp < gap):
                Ewma[n_shift] = 0
                Ewma[i] = Ewma[i-1]
                cp += 1; nan_p[i] = 1
            else: 
                Ewma[i] = 0 
                nan_p[i] = 1
                
            if ((Ewma[i] > L or Ewma[i] < -L) and i < n_shift + 1 and cnt_plus == 0):
                ind = nan_p[0:i]
                RL0[b] = i #- sum(ind)
                cnt_plus += 1
            elif ((Ewma[i] > L or Ewma[i] < -L)  and i > n_shift): 
                ind = nan_p[n_shift:i]
                RL1[b] = i - n_shift #- sum(ind)
                break 
            
            
        if np.isnan(RL1[b]): 
            RL1[b] = n - n_shift
            
        if RL0[b] == 0: 
            RL0[b] = n_shift

           
    ARL1 = np.mean(RL1)
    ARL0 = np.nanmean(RL0)
    return (ARL1, ARL0)

##########################################################################"
""" Tests """

if __name__ == "__main__":            

    
    #### iid normal data tests ####
    #table 5.1 Qiu(2013)
    data = np.random.normal(0, 1, size=(10000,1))
    ARL0_EWMA_MV(data, rho=2.635, block_length=1) #200
    ARL0_EWMA_MV(data, 1.859, lambd=0.01, block_length=1) #400
    ARL0_EWMA_MV(data, 2.268, lambd=0.5, block_length=1) #50
    ARL0_EWMA_MV(data, 3.087, lambd=0.75, block_length=1) #500
    #table 5.3 Qiu(2013)
    #do nor work
    #ARL0_EWMA_MV(data, rho=2.54, lambd=0.212, two_sided=False, 
    #block_length=1) #200

    search_EWMA_MV(data, rho_plus=4, block_length=1) #2.635
    search_EWMA_MV(data, lambd=0.01, rho_plus=2, ARL0_threshold=100,
                   block_length=1) #1.152
    search_EWMA_MV(data, lambd=0.5, ARL0_threshold=50, rho_plus=4, 
                   block_length=1) #2.268

    #Figure 5.4 (Qiu)
    ARL1_EWMA_MV(data, 2.216, lambd=0.05, delta=2, block_length=1)#4.467
    ARL1_EWMA_MV(data, 2.216, lambd=0.05, delta=1, block_length=1)#9.344
    ARL1_EWMA_MV(data, 2.216, lambd=0.05, delta=0.25, block_length=1)#55.401
    
    ARL1_EWMA_MV(data, 2.454, lambd=0.1, delta=2, block_length=1)#3.844
    ARL1_EWMA_MV(data, 2.454, lambd=0.1, delta=1, block_length=1)#8.52
    ARL1_EWMA_MV(data, 2.454, lambd=0.1, delta=0.25, block_length=1)#62.61
    
    ARL1_EWMA_MV(data, 2.635, lambd=0.2, delta=2, block_length=1)#3.265
    ARL1_EWMA_MV(data, 2.635, lambd=0.2, delta=1, block_length=1)#8.37
    ARL1_EWMA_MV(data, 2.635, lambd=0.2, delta=0.25, block_length=1)#77.91

    ARL_values_EWMA_MV(data, 2.454, lambd=0.1, delta=2, block_length=1) #200-3.844
    ARL_values_EWMA_MV(data, 2.635, lambd=0.2, delta=0.25, block_length=1) #200-77.91
    

    ####################################################################
    #### sunspots data tests ####
    with open('../../Datasets/data', 'rb') as fichier:
         my_depickler = pickle.Unpickler(fichier)
         data = my_depickler.load() #contain all deviations, even from IC stations
         time = my_depickler.load()
         station_names = my_depickler.load()
         dataIC = my_depickler.load()
         IC_stations= my_depickler.load()
    
    search_EWMA_MV(dataIC, ARL0_threshold=200, block_length=27) #4.51
    ARL1_EWMA_MV(dataIC, rho=4.51, block_length=27) #20.96
    
    search_EWMA_MV(dataIC, ARL0_threshold=500, gap=0, 
                   missing_values='reset', block_length=27) #6
    ARL1_EWMA_MV(dataIC, rho=6, gap=0, missing_values='reset',
                 block_length=27) #40.38
